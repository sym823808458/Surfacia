"""
Machine learning modules for Surfacia
"""



# �����µķ�����
from .chem_ml_analyzer_v2 import (
    BaseChemMLAnalyzer,
    ManualFeatureAnalyzer,
    WorkflowAnalyzer,
    ChemMLWorkflow
)

# Ϊ�˼����ԣ���ChemMLWorkflow��ΪĬ�ϵ�ChemMLAnalyzer
ChemMLAnalyzer = ChemMLWorkflow

__all__ = [
    'ChemMLAnalyzer',
    'ChemMLAnalyzerLegacy',
    'BaseChemMLAnalyzer',
    'ManualFeatureAnalyzer', 
    'WorkflowAnalyzer',
    'ChemMLWorkflow'
]